﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0427과제
{
    class Account
    {
        private int id;  //아이디
        private int balance;//잔액
        private String name; //이름

        #region 프로퍼티

        public int Id
        {
            get { return id; }
             set { id = value; }
        }

        public int Balance
        {
            get { return balance; }
             set { balance = value; } //필요에의 해 은닉가능
        }

        public String Name
        {
            get { return name; }
             set { name = value; }
        }
        #endregion

        #region 생성자
       // public  Account() { }
        public Account(int _id, String _name, int _balance)
        {
            Id = _id;
            Name = _name;
            Balance = _balance;
        }

        public Account(Account acc)
        {
            this.Id = acc.id;
            this.Balance = acc.balance;
            this.Name = acc.name;
        }
        #endregion

        #region 기능 메서드
        public virtual void AddMoney(int val)
        {
            balance = balance + val;
        }
        
        public virtual void MinMoney(int val)
        {
            balance = balance - val;
        }

        public void ShowAllData()
        {
            Console.WriteLine("[계좌ID]:" + id + "\t");
            Console.WriteLine("[이 름]:" + name + "\t");
            Console.WriteLine("[잔  액]:" + balance + "\n");
        }
        #endregion
    }
}
