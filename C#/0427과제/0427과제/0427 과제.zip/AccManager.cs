﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0427과제
{
    class AccManager
    {

        #region 계정정보 배열
        public int index;
        Account[] pArray = new Account[100];
        #endregion

        #region 객체 배열 생성자


        public AccManager()//저정공간 크기
        {
            index = 0;
        }

        #endregion


        #region 프로퍼티
        public Account this[int idx]
        {
            get
            {
                if (idx < 0 || idx >= pArray.Length)
                    throw new Exception("인덱스 접근이 잘못됨");
                return pArray[idx];
            }
            set
            {
                if (idx < 0 || idx >= pArray.Length)
                    throw new Exception("인덱스 접근이 잘못됨");
                pArray[idx] = value;
            }
        }


        #endregion
       // #region 매서드
        public void PrintMenu()// 메뉴 출력
        {
            Console.WriteLine("----- MENU ----- ");
            Console.WriteLine("1.개 좌  개 설 ");
            Console.WriteLine("2.입        금 ");
            Console.WriteLine("3.출        금 ");
            Console.WriteLine("4.잔 액  조 회 ");
            Console.WriteLine("5.프로그램종료 ");
        }

        public void MakeAccount()
        {
            int id;
            String name;
            int balance;
            int sel;
            while (true)
            {

                Console.WriteLine(" 개설할 계좌의 종류........");
                Console.WriteLine("1. 일반 계좌 ");
                Console.WriteLine("2. 신용 계좌 ");
                Console.WriteLine("3. 기부 계좌 ");
                Console.Write(" >>  ");
                sel = int.Parse(Console.ReadLine());
                Console.WriteLine();

                if (sel == 1)
                    break;
                else if (sel == 2)
                    break;
                else if (sel == 3)
                    break;
                else
                    Console.WriteLine(" 잘못 선택");
            }

            Console.WriteLine("개좌 개설 ---------");
            Console.Write("개좌  ID: "); id = int.Parse(Console.ReadLine());
            Console.Write("이    름: "); name = Console.ReadLine();
            Console.Write("입 금 액: "); balance = int.Parse(Console.ReadLine());
            Console.WriteLine();
            if (sel == 1)
                pArray[index++] = new Account(id, name, balance);
            else if (sel == 2)
                pArray[index++] = new FaitAccount(id, name, balance);
            else if (sel == 3)
                pArray[index++] = new ContriAccount(id, name, balance);
        }

        public void Depoist()
        {
            int id;
            int money;

            Console.Write("계좌 ID : "); id = int.Parse(Console.ReadLine());
            Console.Write("입금액: "); money = int.Parse(Console.ReadLine());

            for (int i = 0; i < index; i++)
            {
                if (pArray[i].Id == id)
                {
                    pArray[i].AddMoney(money);
                    Console.WriteLine("입금 완료");
                    return;
                }
            }
            Console.WriteLine("유효하지 않은 ID입니다.");
        }

        public void Withdraw()
        {
            int id;
            int money;

            Console.Write("계좌 ID : "); id = int.Parse(Console.ReadLine());
            Console.Write("출금액 : "); money = int.Parse(Console.ReadLine());

            for (int i = 0; i < index; i++)
            {
                if (pArray[i].Id == id)
                {
                    if (pArray[i].Balance < money)
                    {
                        Console.WriteLine("잔액 부족");
                        return;
                    }

                    pArray[i].MinMoney(money);
                    Console.WriteLine("출금완료");
                    return;
                }
            }
            Console.WriteLine("유효하지 않은 ID입니다.");
        }

        public void Inquire()
        {
            for (int i = 0; i < index; i++)
            {
                pArray[i].ShowAllData();
            }
        }
    }
}
