﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0427과제
{
    class Start
    {
        enum Menu { MAKE = 1, DEPOSIT, WITHDRAW, INQUIRE, EXIT };

        public static void Main(string[] args)
        {
            int choice;
            AccManager manager = new AccManager();

            while (true)
            {
                manager.PrintMenu();
                Console.Write("선택: ");
                choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case (int)Menu.MAKE:
                        manager.MakeAccount();
                        break;
                    case (int)Menu.DEPOSIT:
                        manager.Depoist();
                        break;
                    case (int)Menu.WITHDRAW:
                        manager.Withdraw();
                        break;
                    case (int)Menu.INQUIRE:
                        manager.Inquire();
                        break;
                    case (int)Menu.EXIT:
                        return;
                    default:
                        Console.WriteLine("잘못된 선택");
                        break;
                }
            }
        }
    }
}
