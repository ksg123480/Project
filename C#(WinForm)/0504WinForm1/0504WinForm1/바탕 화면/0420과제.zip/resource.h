﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// My0420.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define ID_INDICATOR_TIME               101
#define ID_INDICATOR_INFO               102
#define ID_INDICATOR_SHAPENUM           103
#define IDR_MAINFRAME                   128
#define IDR_My0420TYPE                  130
#define ID_32771                        32771
#define ID_INDICATOR_POS                32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_32774                        32774
#define ID_32775                        32775
#define ID_RES                          32776
#define ID_RED                          32777
#define ID_GREEN                        32778
#define ID_BLUE                         32779
#define ID_SQURE                        32780
#define ID_ECLIPCE                      32781

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        310
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
