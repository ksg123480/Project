﻿
// 0420Doc.cpp: CMy0420Doc 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "0420.h"
#endif

#include "0420Doc.h"

#include <propkey.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMy0420Doc

IMPLEMENT_DYNCREATE(CMy0420Doc, CDocument)

BEGIN_MESSAGE_MAP(CMy0420Doc, CDocument)
	ON_COMMAND(ID_RED, &CMy0420Doc::OnRed)
	ON_COMMAND(ID_GREEN, &CMy0420Doc::OnGreen)
	ON_COMMAND(ID_BLUE, &CMy0420Doc::OnBlue)
	ON_COMMAND(ID_SQURE, &CMy0420Doc::OnSqure)
	ON_COMMAND(ID_ECLIPCE, &CMy0420Doc::OnEclipce)
END_MESSAGE_MAP()


// CMy0420Doc 생성/소멸

CMy0420Doc::CMy0420Doc() noexcept
{
	// TODO: 여기에 일회성 생성 코드를 추가합니다.
	m_curshape.color = RGB(0, 0, 0);
	m_curshape.pt.x = 0;
	m_curshape.pt.y = 0;
	m_curshape.type = 1;
	m_curshape.width = 1;
}

CMy0420Doc::~CMy0420Doc()
{
}

BOOL CMy0420Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: 여기에 재초기화 코드를 추가합니다.
	// SDI 문서는 이 문서를 다시 사용합니다.
	m_pointlist.clear();

	POSITION pos = GetFirstViewPosition();
	GetNextView(pos)->Invalidate(TRUE);

	return TRUE;
}




// CMy0420Doc serialization

void CMy0420Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: 여기에 저장 코드를 추가합니다.
		int size = m_pointlist.size();

		ar << size;

		for (int i = 0; i < (int)m_pointlist.size(); i++)
		{
			CMyShape shape = m_pointlist[i];
			ar << shape.color << shape.pt << shape.type << shape.width;
		}
	}
	else
	{
		// TODO: 여기에 로딩 코드를 추가합니다.
		m_pointlist.clear();
		//Doc -> View
		POSITION pos = GetFirstViewPosition();
		GetNextView(pos)->Invalidate(TRUE);

		int size;
		ar >> size;
		for (int i = 0; i < size; i++)
		{
			CMyShape temp;
			ar >> temp.color >> temp.pt >> temp.type >> temp.width;
			m_pointlist.push_back(temp);
		}
	}
}

#ifdef SHARED_HANDLERS

// 축소판 그림을 지원합니다.
void CMy0420Doc::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// 문서의 데이터를 그리려면 이 코드를 수정하십시오.
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// 검색 처리기를 지원합니다.
void CMy0420Doc::InitializeSearchContent()
{
	CString strSearchContent;
	// 문서의 데이터에서 검색 콘텐츠를 설정합니다.
	// 콘텐츠 부분은 ";"로 구분되어야 합니다.

	// 예: strSearchContent = _T("point;rectangle;circle;ole object;");
	SetSearchContent(strSearchContent);
}

void CMy0420Doc::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = nullptr;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != nullptr)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CMy0420Doc 진단

#ifdef _DEBUG
void CMy0420Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMy0420Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CMy0420Doc 명령


void CMy0420Doc::OnRed()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	m_curshape.color = RGB(255, 0, 0);
}


void CMy0420Doc::OnGreen()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	m_curshape.color = RGB(0, 255, 0);
}


void CMy0420Doc::OnBlue()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	m_curshape.color = RGB(0, 0, 255);
}


void CMy0420Doc::OnSqure()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	m_curshape.type = 1;
}


void CMy0420Doc::OnEclipce()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	m_curshape.type = 2;
}
