﻿
// 0420View.cpp: CMy0420View 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "0420.h"
#endif

#include "0420Doc.h"
#include "0420View.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMy0420View

IMPLEMENT_DYNCREATE(CMy0420View, CView)

BEGIN_MESSAGE_MAP(CMy0420View, CView)
	ON_WM_LBUTTONDOWN()
	ON_WM_KEYDOWN()
	ON_WM_MOUSEMOVE()
	ON_UPDATE_COMMAND_UI(ID_GREEN, &CMy0420View::OnUpdateGreen)
	ON_UPDATE_COMMAND_UI(ID_RED, &CMy0420View::OnUpdateRed)
	ON_UPDATE_COMMAND_UI(ID_BLUE, &CMy0420View::OnUpdateBlue)
	ON_UPDATE_COMMAND_UI(ID_SQURE, &CMy0420View::OnUpdateSqure)
	ON_UPDATE_COMMAND_UI(ID_ECLIPCE, &CMy0420View::OnUpdateEclipce)
END_MESSAGE_MAP()

// CMy0420View 생성/소멸

CMy0420View::CMy0420View() noexcept
{
	// TODO: 여기에 생성 코드를 추가합니다.

}

CMy0420View::~CMy0420View()
{
}

BOOL CMy0420View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.

	return CView::PreCreateWindow(cs);
}

// CMy0420View 그리기

void CMy0420View::OnDraw(CDC* pDC)
{
	CMy0420Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: 여기에 원시 데이터에 대한 그리기 코드를 추가합니다.

	for (int i = 0; i < (int)pDoc->m_pointlist.size(); i++)
	{
		CMyShape shape = pDoc->m_pointlist[i];

		CBrush br(shape.color);
		CBrush* pOldbr = (CBrush*)pDC->SelectObject(&br);

		CPen pen(PS_SOLID, shape.width, RGB(0, 0, 0));
		CPen* pOldpen = (CPen*)pDC->SelectObject(&pen);

		if (shape.type == 1)
		{
			pDC->Rectangle(shape.pt.x, shape.pt.y, shape.pt.x + 50, shape.pt.y + 50);
		}
		else
		{
			pDC->Ellipse(shape.pt.x, shape.pt.y, shape.pt.x + 50, shape.pt.y + 50);
		}
		pDC->SelectObject(pOldbr);
		pDC->SelectObject(pOldpen);
	}

}


// CMy0420View 진단

#ifdef _DEBUG
void CMy0420View::AssertValid() const
{
	CView::AssertValid();
}

void CMy0420View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMy0420Doc* CMy0420View::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMy0420Doc)));
	return (CMy0420Doc*)m_pDocument;
}
#endif //_DEBUG


// CMy0420View 메시지 처리기


void CMy0420View::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	
	if (nFlags & MK_CONTROL)
	{
		GetDocument()->m_pointlist.pop_back();
	}
	else
	{
		GetDocument()->m_curshape.pt = point;
		CMyShape shape = GetDocument()->m_curshape;
		GetDocument()->m_pointlist.push_back(shape);
	}
	int count = GetDocument()->m_pointlist.size();

	CString temp;
	temp.Format(TEXT("저장갯수 : %d개"), count);

	CString str;
	str.Format(TEXT("[%d개]"), GetDocument()->m_pointlist.size());
	((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetPaneText(3, str);

	AfxGetMainWnd()->SetWindowText(temp);

	Invalidate(TRUE);

	CView::OnLButtonDown(nFlags, point);
}


void CMy0420View::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	switch (nChar)
	{
	case 0x31:
		GetDocument()->m_curshape.width = 1;
		break;
	case 0x32:
		GetDocument()->m_curshape.width = 2;
		break;
	case 0x33:
		GetDocument()->m_curshape.width = 3;
		break;
	case 0x34:
		GetDocument()->m_curshape.width = 4;
		break;
	case 0x35:
		GetDocument()->m_curshape.width = 5;
		break;
	default:
		break;
	}

	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}


void CMy0420View::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	CString str;
	CTime t = CTime::GetCurrentTime();
	str.Format(TEXT("%2d:%2d"), t.GetHour(), t.GetMinute());
	((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetPaneText(1, str);
	
	switch (GetDocument()->m_curshape.color)
	{
	case RGB(0, 0, 0):
		str.Format(TEXT("[검정]"));
		break;
	case RGB(255, 0, 0):
		str.Format(TEXT("[빨강]"));
		break;
	case RGB(0, 255, 0):
		str.Format(TEXT("[초록]"));
		break;
	case RGB(0, 0, 255):
		str.Format(TEXT("[파랑]"));
		break;
	default:
		break;
	}
	
	str.Format(TEXT("%s[%d]"), str, GetDocument()->m_curshape.width);

	switch (GetDocument()->m_curshape.type)
	{
	case 1:
		str += "[네모]";
		break;
	case 2:
		str += "[타원]";
		break;
	default:
		break;
	}
	
	((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetPaneText(2, str);
	
	str.Format(TEXT("%4d,%4d"), point.x, point.y);
	((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetPaneText(4, str);

	CView::OnMouseMove(nFlags, point);
}


void CMy0420View::OnUpdateRed(CCmdUI* pCmdUI)
{
	// TODO: 여기에 명령 업데이트 UI 처리기 코드를 추가합니다.
	pCmdUI->SetCheck(GetDocument()->m_curshape.color == RGB(255, 0, 0));
}


void CMy0420View::OnUpdateGreen(CCmdUI* pCmdUI)
{
	// TODO: 여기에 명령 업데이트 UI 처리기 코드를 추가합니다.
	pCmdUI->SetCheck(GetDocument()->m_curshape.color == RGB(0, 255, 0));
}


void CMy0420View::OnUpdateBlue(CCmdUI* pCmdUI)
{
	// TODO: 여기에 명령 업데이트 UI 처리기 코드를 추가합니다.
	pCmdUI->SetCheck(GetDocument()->m_curshape.color == RGB(0,0, 255));
}


void CMy0420View::OnUpdateSqure(CCmdUI* pCmdUI)
{
	// TODO: 여기에 명령 업데이트 UI 처리기 코드를 추가합니다.
	pCmdUI->SetCheck(GetDocument()->m_curshape.type == 1);
}


void CMy0420View::OnUpdateEclipce(CCmdUI* pCmdUI)
{
	// TODO: 여기에 명령 업데이트 UI 처리기 코드를 추가합니다.
	pCmdUI->SetCheck(GetDocument()->m_curshape.type == 2);

}
