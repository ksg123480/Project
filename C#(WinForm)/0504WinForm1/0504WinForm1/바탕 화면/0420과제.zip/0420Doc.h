﻿
// 0420Doc.h: CMy0420Doc 클래스의 인터페이스
//


#pragma once

#include <vector>
using namespace std;

class CMy0420Doc : public CDocument
{
protected: // serialization에서만 만들어집니다.
	CMy0420Doc() noexcept;
	DECLARE_DYNCREATE(CMy0420Doc)

// 특성입니다.
public:
	vector<CMyShape> m_pointlist;	//전체리스트
	CMyShape m_curshape;			//현재 설정 정보

// 작업입니다.
public:

// 재정의입니다.
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
#ifdef SHARED_HANDLERS
	virtual void InitializeSearchContent();
	virtual void OnDrawThumbnail(CDC& dc, LPRECT lprcBounds);
#endif // SHARED_HANDLERS

// 구현입니다.
public:
	virtual ~CMy0420Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 생성된 메시지 맵 함수
protected:
	DECLARE_MESSAGE_MAP()

#ifdef SHARED_HANDLERS
	// 검색 처리기에 대한 검색 콘텐츠를 설정하는 도우미 함수
	void SetSearchContent(const CString& value);
#endif // SHARED_HANDLERS
public:
	afx_msg void OnRed();
	afx_msg void OnGreen();
	afx_msg void OnBlue();
	afx_msg void OnSqure();
	afx_msg void OnEclipce();
};
