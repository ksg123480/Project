#pragma once
class CMyShape 
{
public:
	CPoint pt;
	COLORREF color;
	int type;
	int width;

public:
	CMyShape(){}
	CMyShape(CPoint _pt, COLORREF _color, int _type, int _width)
	{
		pt = _pt;
		color = _color;
		type = _type;
		width = _width;
	}
};

