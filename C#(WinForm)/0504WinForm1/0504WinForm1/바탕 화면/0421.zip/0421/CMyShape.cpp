#include "pch.h"
#include "CMyShape.h"
