#pragma once
class CMyShape
{
public:
	COLORREF color;
	int type;


public:
	CMyShape() {}
	CMyShape(COLORREF _color , int _type)
	{
		color = _color;
		type = _type;
	}
	
};

