﻿
// 0421View.h: CMy0421View 클래스의 인터페이스
//

#pragma once


class CMy0421View : public CView
{
protected: // serialization에서만 만들어집니다.
	CMy0421View() noexcept;
	DECLARE_DYNCREATE(CMy0421View)

// 특성입니다.
public:
	CMy0421Doc* GetDocument() const;

// 작업입니다.
public:

// 재정의입니다.
public:
	virtual void OnDraw(CDC* pDC);  // 이 뷰를 그리기 위해 재정의되었습니다.
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:

// 구현입니다.
public:
	virtual ~CMy0421View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 생성된 메시지 맵 함수
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnColorRed();
	afx_msg void OnColorGreen();
	afx_msg void OnColorBlue();
	afx_msg void OnColorEtc();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
};

#ifndef _DEBUG  // 0421View.cpp의 디버그 버전
inline CMy0421Doc* CMy0421View::GetDocument() const
   { return reinterpret_cast<CMy0421Doc*>(m_pDocument); }
#endif

