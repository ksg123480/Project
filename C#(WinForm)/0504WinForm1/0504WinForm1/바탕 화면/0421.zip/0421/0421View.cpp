﻿
// 0421View.cpp: CMy0421View 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "0421.h"
#endif

#include "0421Doc.h"
#include "0421View.h"
#include"MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMy0421View

IMPLEMENT_DYNCREATE(CMy0421View, CView)

BEGIN_MESSAGE_MAP(CMy0421View, CView)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_COMMAND(ID_COLOR_RED, &CMy0421View::OnColorRed)
	ON_COMMAND(ID_COLOR_GREEN, &CMy0421View::OnColorGreen)
	ON_COMMAND(ID_COLOR_BLUE, &CMy0421View::OnColorBlue)
	ON_COMMAND(ID_COLOR_ETC, &CMy0421View::OnColorEtc)
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()

// CMy0421View 생성/소멸

CMy0421View::CMy0421View() noexcept
{
	// TODO: 여기에 생성 코드를 추가합니다.

}

CMy0421View::~CMy0421View()
{
}

BOOL CMy0421View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.

	return CView::PreCreateWindow(cs);
}

// CMy0421View 그리기

void CMy0421View::OnDraw(CDC* /*pDC*/)
{
	CMy0421Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: 여기에 원시 데이터에 대한 그리기 코드를 추가합니다.
}

void CMy0421View::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CMy0421View::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CMy0421View 진단

#ifdef _DEBUG
void CMy0421View::AssertValid() const
{
	CView::AssertValid();
}

void CMy0421View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMy0421Doc* CMy0421View::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMy0421Doc)));
	return (CMy0421Doc*)m_pDocument;
}
#endif //_DEBUG


// CMy0421View 메시지 처리기


void CMy0421View::OnColorRed()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	GetDocument()->m_curShape.color = RGB(255, 0, 0);

	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame);

	((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetPaneBackgroundColor(2, RGB(255, 0, 0));
	((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetPaneText(2, TEXT("빨강색"));
}


void CMy0421View::OnColorGreen()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	GetDocument()->m_curShape.color = RGB(0, 255, 0);

	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame);

	((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetPaneBackgroundColor(2, RGB(0, 255, 0));
	((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetPaneText(2, TEXT("녹색"));

}



void CMy0421View::OnColorBlue()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	GetDocument()->m_curShape.color = RGB(0, 0, 255);

	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame);

	((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetPaneBackgroundColor(2, RGB(0, 0, 255));
	((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetPaneText(2, TEXT("파랑색"));
}


void CMy0421View::OnColorEtc()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.


		// TODO: Add your command handler code here 

		COLORREF color = RGB(0, 0, 0);
		CColorDialog dlg(color);
		if (dlg.DoModal() == IDOK) 
		{
			CString str;
			color = dlg.GetColor();

			str.Format(TEXT("색상 : (%d, %d, %d)"),
				GetRValue(color),GetGValue(color),GetBValue(color));
			AfxMessageBox(str);

		}
	



	GetDocument()->m_curShape.color = color;

	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame);

	((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetPaneBackgroundColor(2, color);
	((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetPaneText(2, TEXT("기타색"));


}


void CMy0421View::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	CString str;

	switch (nChar)
	{
	case 'R':
		GetDocument()->m_curShape.type = 1;
		str.Format(TEXT("사각형"));
			break;
	case 'E':
		GetDocument()->m_curShape.type = 2;
		str.Format(TEXT("타원형"));
			break;
	case 'T':
		GetDocument()->m_curShape.type = 3;
		str.Format(TEXT("삼각형"));
			break;
	default:
		break;
	}

	int type = GetDocument()->m_curShape.type;

	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame);


	((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetPaneText(3, str);

	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}
